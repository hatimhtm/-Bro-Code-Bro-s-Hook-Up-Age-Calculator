package Substraction;

public class Substraction {

    public static int substract(int a, int b) {
        return a - b;
    }
}
