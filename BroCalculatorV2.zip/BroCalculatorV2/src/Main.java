import BroCalculation.*;
import java.util.Scanner;
import java.util.InputMismatchException;
import Addition.*;
import Division.*;
import Multiplication.*;
import Substraction.*;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to the smart calculator!");
        try {

            System.out.print("Please enter the first number: ");
            int firstNumber = sc.nextInt();
            System.out.print("Please enter the second number: ");
            int secondNumber = sc.nextInt();
            System.out.print("Please enter the operation you want to perform: ");
            String operation = sc.next();
            int result = 0;
            switch (operation) {
                case "+":
                    result = Addition.add(firstNumber, secondNumber);
                    break;
                case "-":
                    result = Substraction.substract(firstNumber, secondNumber);
                    break;
                case "*":
                    result = Multiplication.multiply(firstNumber, secondNumber);
                    break;
                case "/":
                    result = Division.divide(firstNumber, secondNumber);
                    break;
                default:
                    System.out.println("Invalid operation!");
                    break;
            }
            System.out.println("The result is: " + result);
        } catch (Exception InputMismatchException) {
            RealCalculator.launchCalc();
        }
    }
}