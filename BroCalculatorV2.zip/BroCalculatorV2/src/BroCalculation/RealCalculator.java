package BroCalculation;

import java.util.Scanner;

public class RealCalculator {

    static int chickMinAge;
    static int chickMaxAge;

    public RealCalculator(int chickMinAge, int chickMaxAge) {
        this.chickMinAge = chickMinAge;
        this.chickMaxAge = chickMaxAge;
    }

    public static int getChickMinAge(int broAge, int chickMinAge) {

        chickMinAge = (broAge / 2) + 7;
        return chickMinAge;
    }

    public static int getMaxAgeIdentifier(int broAge) {

        int maxAgeIdentifier = (broAge / 10) * 2;
        return maxAgeIdentifier;
    }

    public static int getChickMaxAge(int broAge, int maxAgeIdentifier) {

        chickMaxAge = broAge - maxAgeIdentifier;
        return chickMaxAge;
    }
    public static void launchCalc() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome fellow bro to the BroCalculation program!");
        System.out.print("Please enter your age: ");
        int broAge = sc.nextInt();
        System.out.printf("Your chick minimum age is: %d, and the maximum age is: %d\n", getChickMinAge(broAge, chickMinAge), getChickMaxAge(broAge, getMaxAgeIdentifier(broAge)));
    }
}
