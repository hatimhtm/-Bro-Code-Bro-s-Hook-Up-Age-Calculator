import java.util.Scanner;

public class Main {

    static int chickMinAge;
    int broAge;
    static int maxAgeIdentifier;
    static int chickMaxAge;

    public Main(int chickMinAge, int broAge, int maxAgeIdentifier) {

        this.chickMinAge = chickMinAge;
        this.broAge = broAge;
        this.maxAgeIdentifier = maxAgeIdentifier;
    }

    public static int getChickMinAge(int broAge, int chickMinAge) {

        chickMinAge = (broAge / 2) + 7;
        return chickMinAge;
    }

    public static int getMaxAgeIdentifier(int broAge, int maxAgeIdentifier) {

        maxAgeIdentifier = (broAge / 10) * 2;
        return maxAgeIdentifier;
    }

    public static int getChickMaxAge(int broAge, int maxAgeIdentifier) {

        chickMaxAge = broAge - maxAgeIdentifier;
        return chickMaxAge;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Hello there partner.");
        System.out.println("Are you a bro or a chick? ");
        String firstAnswer;
        String secondAnswer;
        firstAnswer = sc.next();

        if (firstAnswer.equals("bro")) {

            System.out.println("To prove that you are a real bro I have a question for you?");
            System.out.println("Is it bro-legal to date your bro's Ex? (y/n) ");
            secondAnswer = sc.next();

            if (secondAnswer.equals("n")) {

                System.out.println("Enter your age bro: ");
                int broAge = sc.nextInt();
                maxAgeIdentifier = getMaxAgeIdentifier(broAge, maxAgeIdentifier);
                System.out.printf("According to the Bro Code, the minimum age of the chick is %d and the maximum age is %d", getChickMinAge(broAge, chickMinAge), getChickMaxAge(broAge, maxAgeIdentifier));
            } else {

                System.out.println("Please chick, never try to invade our bro-temple.");
            }
        } else {
            System.out.println("No offense chick, but this isn't addressed to be used by you");
        }

    }
}